<?php

namespace Common\Auth;

use Illuminate\Database\Eloquent\Model;

class ActiveSession extends Model
{
    protected $guarded = ['id'];
}
