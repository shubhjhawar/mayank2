<?php namespace Common\Billing;

class GatewayException extends \Exception {

}
