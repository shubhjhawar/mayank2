export interface UserLink {
  url: string;
  title: string;
}
