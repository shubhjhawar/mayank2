export interface Reviewable {
  id: number;
  model_type: string;
}
